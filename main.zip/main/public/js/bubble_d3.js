function bubbleChart(Count,ownerCount){
  var tempObj = {};
  var data = [];
  var primary_fields = ["Verticals", "Accounts","Tools","Solutions Nature","Processes"];
  var count = [];
  var limit = primary_fields.length;

  for(i=0;i<ownerCount.data.length;i++){
      primary_fields.push(ownerCount.data[i].name);
  }

  for(i=0;i<primary_fields.length;i++){
    tempObj = {};
    if(i>=5){
      tempObj['Name'] = primary_fields[i];
      tempObj['Count'] = ownerCount.data[i-5].count;
      data.push(tempObj);
    }
    else{
      tempObj['Name'] = primary_fields[i];
      tempObj['Count'] = Count.data[i];
      data.push(tempObj);
    }
  }



var diameter = 500, //max size of the bubbles
    color    = d3.scale.category10(); //color category

var div = d3.select("body").append("div")
    .attr("class", "tooltip")
    .style("opacity", 0);

var bubble = d3.layout.pack()
    .sort(null)
    .size([diameter, diameter])
    .padding(2.5);

var svg = d3.select("#leftSideCard")
    .append("svg")
    .attr("width", diameter)
    .attr("height", diameter)
    .attr("class", "bubble");


   //convert numerical values from strings to numbers
    data = data.map(function(d){ d.value = +d["Count"]; return d; });

    //bubbles needs very specific format, convert data to this.
    var nodes = bubble.nodes({children:data}).filter(function(d) { return !d.children; });

    //setup the chart
    var bubbles = svg.append("g")
        .attr("transform", "translate(0,0)")
        .selectAll(".bubble")
        .data(nodes)
        .enter();

    //create the bubbles
    bubbles.append("circle")
        .attr("r", function(d){ return d.r; })
        .attr("cx", function(d){ return d.x; })
        .attr("cy", function(d){ return d.y; })
        .on("click", function(d) {
          window.open("../views/concept_map.html");
        })
        .on("mouseover", function(d) {
            div.transition()
                .duration(200)
                .style("opacity", .9);
            div.html("<h5>" + d.Name + "</h5>")
            .style("left", (d3.event.pageX) + "px")
            .style("top", (d3.event.pageY - 28) + "px");
            })
        .on("mouseout", function(d) {
           div.transition()
                .duration(500)
                .style("opacity", 0);
        })
        .style("fill", function(d) { return color(d.value); } );

    //format the text for each bubble
    bubbles.append("text")
        .attr("x", function(d){ return d.x; })
        .attr("y", function(d){ return d.y + 5; })
        .attr("text-anchor", "middle")
        .text(function(d){ return  d["Count"]; })
        .style({
            "text-shadow": "2px 2px #FF0000",
            "fill":"black",
            "font-family":"Helvetica Neue, Helvetica, Arial, san-serif",
            "font-size": "3px"
        });
   return name;

}
