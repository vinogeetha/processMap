var processMap = angular.module('processMap',['ngMaterial']);
processMap.factory('GetNameService', function ($http,$q)
{
    return {
        getName: function(str) {
        var url="http://10.219.47.29:8080/auto_nodes/"+str;
            return $http.get(url)
                .then(function(response) {
                    if (typeof response.data === 'object')
                        return response.data;
                    else
                        return $q.reject(response.data);
                }, function(response) {
                        return $q.reject(response.data);
                });
        }
    };
});

processMap.controller('MainCtrl', function($scope, $compile, $mdDialog, $rootScope,$http, GetNameService) {
  $scope.selectedItem = [];
  $scope.searchText = "";
  $scope.text = '';
  $scope.isDisabled = false;
  $scope.noCache = false;
  $scope.searchShow = false;
  $scope.cardDivShow = true;
  $scope.smallCardShow = false;
  $scope.selectedItemChange = function (item) {
        if ($scope.selectedItem)
          $scope.text=$scope.selectedItem.name;
          console.log($scope.text);
        }
    $scope.searchTextChange = function (str) {
      console.log( GetNameService.getName(str));
        return GetNameService.getName(str);
    }

// Search function
   $scope.getData = function(text){
     $scope.searchShow = true;
     $scope.cardDivShow = false;
     $http.get('http://10.219.47.29:8080/search/'+$scope.text)
     .then(function(result){
       drawSearchGraph('#searchCard',result.data);
     })
   }

   $http.get('http://10.219.47.29:8080/vertical')
     .then(function(result){
         drawBubbleChart(result,'#ACard');
     })

  $http.get('http://10.219.47.29:8080/count')
    .then(function(result){
      $http.get('http://10.219.47.29:8080/countOwner')
        .then(function(subresult){
          bubbleChart(result,subresult);
        })
    })
  var obj = {};
  $rootScope.subArray = [];
  var index = 0;
  var count=0;
    //  $http.get('http://10.219.47.29:8080/top/Nature_of_solution')
    // .then(function(result){
    //   obj = result;
    //   getTopTools(obj.data[index]);
    //   getTopTools(obj.data[index+1]);
    //   getTopTools(obj.data[index+2]);
    //   // drawTreeMap(result,$rootScope.subArray);
    //
    // });

    $scope.getTop  = function(name){
      console.log(name);
      $http.get('http://10.219.47.29:8080/top/'+name)
      .then(function(result){
        drawTopGraph(result);
      })
    }

    function getTopTools(data){
      $http.get('http://10.219.47.29:8080/topCollection/'+data)
       .then(function(subresult){
         $rootScope.subArray.push(subresult.data)
       })
    }


 // drawTreeMap(data,subdata);
});
