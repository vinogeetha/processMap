function drawBubbleChart(count,divName){
  var totalCount = 0;
  var total = count.data.length;
  for(i=0;i<total;i++)
    totalCount = totalCount + count.data[i].count;


  var data = [];
  var tempObj = {};
  tempObj.name = "verticals" + "  Unique:"+ total;
  tempObj.count = totalCount;
  count.data.push(tempObj);
  data = count.data;
  console.log(data);



var diameter = 300, //max size of the bubbles
    color    = d3.scale.category20c(); //color category

var div = d3.select("body").append("div")
    .attr("class", "tooltip")
    .style("opacity", 0);

var bubble = d3.layout.pack()
    .sort(null)
    .size([diameter, diameter])
    .padding(2.5);

var svg = d3.select(divName)
    .append("svg")
    .attr("width", diameter)
    .attr("height", diameter)
    .attr("class", "bubble");


   //convert numerical values from strings to numbers
    data = data.map(function(d){ d.value = +d["count"]; return d; });

    //bubbles needs very specific format, convert data to this.
    var nodes = bubble.nodes({children:data}).filter(function(d) { return !d.children; });

    //setup the chart
    var bubbles = svg.append("g")
        .attr("transform", "translate(0,0)")
        .selectAll(".bubble")
        .data(nodes)
        .enter();

    //create the bubbles
    bubbles.append("circle")
        .attr("r", function(d){ return d.r; })
        .attr("cx", function(d){ return d.x; })
        .attr("cy", function(d){ return d.y; })
        .on("click", function(d) {
          window.open("../views/concept_map.html");
        })
        .on("mouseover", function(d) {
            div.transition()
                .duration(200)
                .style("opacity", .9);
            div.html("<p>" + d.name + "</p>")
            .style("left", (d3.event.pageX) + "px")
            .style("top", (d3.event.pageY - 28) + "px");
            })
        .on("mouseout", function(d) {
           div.transition()
                .duration(500)
                .style("opacity", 0);
        })
        .style("fill", "#22a7f0");

    //format the text for each bubble
    bubbles.append("text")
        .attr("x", function(d){ return d.x; })
        .attr("y", function(d){ return d.y + 5; })
        .attr("text-anchor", "middle")
        .text(function(d){ return d["count"]; })
        .style({
            "fill":"black",
            "font-family":"Helvetica Neue, Helvetica, Arial, san-serif",
            "font-size": "11px"
        });
   return name;

}
