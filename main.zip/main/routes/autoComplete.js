var express = require('express');
var router = express.Router();
var app = express()
var neo4j = require('neo4j-driver').v1;
// var driver = neo4j.driver("bolt://localhost", neo4j.auth.basic("neo4j", "1234"));
var driver = neo4j.driver("bolt://10.219.47.30:7687", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var data = {};
data['links'] = [];
var link_data = ['source','target','relation']

function convertToStructure (result){
  for(i=0;i<result.records.length;i++)
  {
    tempObject = {};
    for(j=0;j<link_data.length;j++)
    {
      if(j<link_data.length-1)
            tempObject[link_data[j]] = result.records[i]._fields[j].properties.name;
      if(j==link_data.length-1)
            tempObject[link_data[j]] = result.records[i]._fields[j][0].type;
    }
    data.links.push(tempObject);
  }
  return data.links;
}


var auto_data=[];
var check2=function(i,result)
{
	auto_data.push(result.records[i]._fields[0].properties);

};

router.get('/:str', function(req, res) {
		var s = req.params.str;
		session.run( "MATCH (n:tools1)-[r:Customer_Implementation|:Process_or_Sub_Process|:Nature_of_solution|:Name_of_technology_solution]-() WHERE n.name STARTS WITH '"+ s +"' RETURN distinct n")
	  .then( function( result ) {
      	auto_data=[];
				for(var i=0;i<result.records.length;i++)
				{
				check2(i,result);
				}
				res.send(auto_data);
        auto_data=[];
	  })
});

module.exports = router;
