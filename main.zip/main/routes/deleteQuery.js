var express = require('express');
var router = express.Router();
var app = express()
var neo4j = require('neo4j-driver').v1;
// var driver = neo4j.driver("bolt://localhost", neo4j.auth.basic("neo4j", "1234"));
var driver = neo4j.driver("bolt://10.219.47.30:7687", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var neodata = {};

router.get('/:nodeName', function(req, res, next) {
  var nodeName  = req.params.nodeName;
  session
      .run( "MATCH (n:tools1 { name:'"+nodeName+"' }) DETACH DELETE n" )
      .then( function( result ) {
          console.log("Node deleted");
      })
  res.send('Delete API Success !!');
});

module.exports = router;
