var express = require('express');
var router = express.Router();
var app = express()
var neo4j = require('neo4j-driver').v1;
// var driver = neo4j.driver("bolt://localhost", neo4j.auth.basic("neo4j", "1234"));
var driver = neo4j.driver("bolt://10.219.47.30:7687", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var data = [];
var index = 0;
var link_data = ['source','target','relation']

function convertToStructure (result){
  for (var i = 0; i < result.records[index]._fields.length; i++) {
    data.push(result.records[index]._fields[i].low);
  }
    return data;
}
router.get('/', function(req, res, next) {
  session
      .run( "MATCH (n:tools1)-[r:Process_or_Sub_Process]->(m:tools1)-[r1:Nature_of_solution]->(o:tools1)-[r2:Name_of_technology_solution]->(p:tools1) return count(distinct n),count(distinct m),count(distinct o),count(distinct p)" )
      .then( function( result ) {
        result = convertToStructure(result);
        session
            .run( "MATCH (n:tools1)-[r:Name_of_technology_solution]->(o:tools1)-[r1:Customer_Implementation]->(p:tools1) return count(distinct p)")
            .then( function( subresult ) {
              subresult = convertToStructure(subresult);
                  res.json(subresult);
                  data = [];
      })
})
});






module.exports = router;
