var express = require('express');
var router = express.Router();
var app = express()
var neo4j = require('neo4j-driver').v1;
// var driver = neo4j.driver("bolt://localhost", neo4j.auth.basic("neo4j", "1234"));
var driver = neo4j.driver("bolt://10.219.47.30:7687", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var data = [];
var tempObj = {};
var index = 0;
var link_data = ['source','target','relation']

function convertToStructure (result){
  for (var i = 0; i < result.records.length; i++) {
    tempObj = {};
    tempObj['name'] = result.records[i]._fields[index];
    tempObj['count'] = result.records[i]._fields[1].low;
    data.push(tempObj);
  }
    return data;
}
router.get('/', function(req, res, next) {
  session
            .run( "MATCH (n:tools1)-[r:Process_or_Sub_Process]->(o:tools1) return distinct n.name,count(n)")
            .then( function( subresult ) {
              subresult = convertToStructure(subresult);
                  res.json(subresult);
        })
});

module.exports = router;
