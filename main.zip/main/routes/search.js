var express = require('express');
var router = express.Router();
var app = express()
var neo4j = require('neo4j-driver').v1;
// var driver = neo4j.driver("bolt://localhost", neo4j.auth.basic("neo4j", "1234"));
var driver = neo4j.driver("bolt://10.219.47.30:7687", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var data = {};
data['links'] = [];
var link_data = ['source','target','relation']
var index = 0;

function convertToStructure (result){
  for(i=0;i<result.records.length;i++)
  {
    tempObject = {};
    for(j=0;j<link_data.length;j++)
            tempObject[link_data[j]] = result.records[i]._fields[index][j];
    data.links.push(tempObject);
  }
  return data.links;
}


router.get('/:nodeName', function(req, res, next) {
  var nodeName  = req.params.nodeName;
  session
      .run( "MATCH (n:tools1)-[r]->(m:tools1) WHERE n.name = '"+nodeName+"' return   distinct [n.name,m.name,type(r)] as result" )
      .then( function( result ) {
        result = convertToStructure(result)
        res.json(result);
        console.log(result);
        data.links = [];
      })


});

module.exports = router;
