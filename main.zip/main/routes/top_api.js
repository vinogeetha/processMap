var express = require('express');
var router = express.Router();
var app = express()
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.47.30:7687", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var data = [];
var collection = [];
var combinedResult = {};
var index = 0;
var link_data = ['source','target','relation']

function convertToStructure (result){
  for (var i = 0; i < result.records.length; i++) {
    data.push(result.records[i]._fields[index]);
  }
    return data;
}
router.get('/:topNode', function(req, res, next) {
  var top = req.params.topNode;
  session
      .run( "MATCH (u:tools1)-[r:"+top+"]->(m:tools1) RETURN m.name, count(m) ORDER BY count(m) DESC LIMIT 3" )
      .then( function( result ) {
      var  result = convertToStructure(result);
            res.json(result);
            data = [];
      })

session.close();

});

module.exports = router;
