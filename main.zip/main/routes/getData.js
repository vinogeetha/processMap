var express = require('express');
var router = express.Router();
var app = express()
var neo4j = require('neo4j-driver').v1;
// var driver = neo4j.driver("bolt://localhost", neo4j.auth.basic("neo4j", "1234"));
var driver = neo4j.driver("bolt://10.219.47.30:7687", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var neodata = {};

router.get('/', function (req, res) {
  var label = req.params.label;
  session
    .run( "MATCH (a:tools1)-[r]-(b:tools1) RETURN a,b,r" )
    .then( function( result ) {
        console.log("Successfully received data !!");

      var tempObject = {};
      var data = {};
      var link_data = ['source','target','relation']
      data['links'] = [];
      for(i=1;i<result.records.length;i=i+2)
      {
        tempObject = {};
        for(j=0;j<link_data.length;j++)
        {
          if(j<link_data.length-1)
                tempObject[link_data[j]] = result.records[i]._fields[j].properties.name;
          if(j==link_data.length-1)
                tempObject[link_data[j]] = result.records[i]._fields[j].type;
        }
        data.links.push(tempObject);
      }
      res.header("Access-Control-Allow-Origin", "*");
      res.json(data['links']);
    })
})
module.exports = router;
