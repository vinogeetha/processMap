var express = require('express');
var router = express.Router();
var bodyParser = require("body-parser");
var app = express()
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.47.30:7687", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var dataArray = [];
var collection = {};
var combinedResult = {};
var index = 0;
var link_data = ['source','target','relation']


router.get('/:data', function(req, res, next) {
  var data = req.params.data;

session
    .run( "MATCH (u:tools1)-[r2:Nature_of_solution]->(m:tools1{name:'"+data+"'}) RETURN u.name limit 3" )
    .then( function( subresult ) {
    dataArray = [];
     for(i=0;i<link_data.length;i++){
       dataArray.push(subresult.records[i]._fields[index]);
   }
    res.send(dataArray);
    dataArray = [];
    })
});
module.exports = router;
